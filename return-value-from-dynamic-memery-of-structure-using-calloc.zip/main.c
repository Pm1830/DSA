#include<stdio.h>
#include<stdlib.h>
struct st 
{
	char n[50];
	int roll;
	float marks;
};
struct st** marks(struct st **,int );
void main()
{	struct st **p;
	int len,i;
	printf("enter the number of students you want=");
	scanf("%d",&len) ;
	p=calloc(len,sizeof(struct st));
	for(i=0; i<len; i++)
		p[i]=calloc(1,sizeof(struct st));

	for(i=0; i<len; i++)
	{
		printf("enter the name=");
		scanf("%s",p[i]->n);
		printf("enter the roll=");
		scanf("%d",&p[i]->roll);
		printf("enter the marks=");
		scanf("%f",&p[i]->marks);
	}
	

    struct st **q=marks(p,len);
    for(i=0;i<len;i++)
    printf("%d %s %f\n",q[i]->roll,q[i]->n,q[i]->marks);
}
struct st** marks(struct st **p,int len)
{	struct st *t;
	for(int j=0; j<len; j++)
		for(int i=j+1; i<len; i++)
			if((p[j]->marks)>(p[i]->marks))
			{
				t=p[j];
				p[j]=p[i];
				p[i]=t;
			}
	return p;

}