typedef struct st {
    char n[20];
    int roll;
    float f;
    struct st *next;
}sl;
void  deletenode(sl **);
void  serchnode(sl *);
void readdata(sl *);
void creat( sl **);
void print(sl * );
int count(sl  *);
void savefile(sl *);
void creat( sl **p)
{
    sl *new;
    new=malloc(sizeof(sl));
    printf("-------------------------------------\n");
    printf("ente name rollnumber marks\n");
    printf("-------------------------------------\n");
    scanf("%s %d %f",new->n,&new->roll,&new->f);
    new->next=*p;
    *p=new;
}
void print(sl *p)
{  if(p==0)
printf("no more rec found");
printf("-------------------------------------\n");
    while(p){
    printf("%s %d %f\n",p->n,p->roll,p->f);
    p=p->next;
}printf("-------------------------------------\n");
    
}
int count (sl *p)
{int c=0;
    while(p)
    {c++;
        p=p->next;
    }
    return c;
}
void savefile(sl *p)
{
    FILE *fp;
    fp=fopen("data","w+");
    while(p){
    fprintf(fp,"%s %d %f\n",p->n,p->roll,p->f);
    p=p->next;}
    fclose(fp);
}
void readdata(sl *p)
{
    FILE *fp;
    sl *new;
    new=malloc(sizeof(sl));
    fp=fopen("data","r");
    fscanf(fp,"%s %d %f",p->n,&p->roll,&p->f);
    printf("-------------------------------------\n");
    printf("%s %d %f",new->n,new->roll,new->f);
printf("-------------------------------------\n");
    
}
void serchnode(sl *p)
{
    int i;
    printf("enter the rollnumber =");
    scanf("%d",&i);
    while(p)
    {
        if(i==p->roll)
        {printf("-------------------------------------\n");
         printf("%s %d %f\n",p->n,p->roll,p->f);
         printf("-------------------------------------\n");}
         
         p=p->next;
        
    }
}
void deletenode(sl **p)
{sl *lp,*fp,*temp;
    int i;
    printf("-------------------------------------\n");
    printf("enter the rollnumber =");
    scanf("%d",&i);
    printf("-------------------------------------\n");
    lp=*p;
    lp=lp->next;
    fp=*p;
    while(lp)
    {
        if(i==lp->roll)
         {temp->next=lp->next;
         free(lp);
           fp->next=temp->next;
             return;
         }
         
         lp=lp->next;
         fp=fp->next;
        
    }
}
