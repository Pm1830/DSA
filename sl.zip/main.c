#include<stdio.h>
#include<stdlib.h>
#include"header.h"
void main()
{
  sl *head=0;
  int i,r;
   while(1){
       printf("-------------------------------------\n");
  printf("1=creat node \n2=print\n3=count nodes\n4=exit\n5=savefile\n6=read data\n7=serch node\n8=delete node\n");
 printf("-------------------------------------\n");
  scanf("%d",&i);
  

  if(i==1)
  creat(&head);
  else if(i==2)
  print(head);
  else if(i==3)
  {r=count(head);
  printf("number of nodes=%d\n",r);}
  else if(i==4)
  exit(0);
  else if(i==5)
  savefile(head);
  else if (i==6)
  readdata(head);
  else if(i==7)
  serchnode(head);
  else if(i==8)
 { deletenode(&head); savefile(head);}
   
 }
}
